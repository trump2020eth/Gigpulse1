import { MD3DarkTheme } from 'react-native-paper';
export const theme={...MD3DarkTheme,colors:{...MD3DarkTheme.colors,primary:'#2ECC71',secondary:'#1ABC9C',background:'#0b0b0b',surface:'#141414',outline:'#222',text:'#fff'}};
